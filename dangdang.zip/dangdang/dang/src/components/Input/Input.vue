<template>
  <div id="main">
    <div class="logo">
      <img
        src="http://img61.ddimg.cn/upload_img/00405/luyi/DDlogoNEW.gif"
        alt=""
      />
    </div>
    <div class="search">
      <el-autocomplete
        v-model="state"
        :fetch-suggestions="querySearchAsync"
        placeholder="福尔摩斯"
        @select="handleSelect"
      ></el-autocomplete>
      <el-select v-model="value" placeholder="全部分类" slot="suffix">
        <el-option-group
          v-for="group in options"
          :key="group.label"
          :label="group.label"
        >
          <el-option
            v-for="item in group.options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-option-group>
      </el-select>
      <el-button slot="append" icon="el-icon-search" @click="log"></el-button>
    </div>
    <div
      class="subBox"
      style="
        width: 700px;
        height: 30px;
        position: absolute;
        left: 440px;
        top: 70px;
        font-size: 10px;
      "
    >
      热搜:
      <a href="#/wait">立体书</a>
      <a href="#/wait">铅笔俱乐部</a>
      <a href="#/wait">爱美生产力</a>
      <a href="#/wait">2023一本</a>
      <a href="#/wait">星期六</a>
      <a href="#/wait">高效学习法</a>
      <a href="#/wait">高级搜索</a>
    </div>
    <div
      class="buy"
      @mouseover.stop="addBg"
      @mouseout.stop="removeBg"
      @click="href"
    >
      <i class="el-icon-shopping-cart-2"></i>
      购物车
      <b style="font-weight: 700">0</b>
    </div>
    <div
      class="list"
      @mouseover.stop="addC"
      @mouseout.stop="removeC"
      @click="href"
    >
      我的订单
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      restaurants: [],
      state: "",
      timeout: null,
      options: [
        {
          label: "",
          options: [
            {
              value: "全部分类",
              label: "全部分类",
            },
            {
              value: "尾品汇",
              label: "尾品汇",
            },
            {
              value: "图书",
              label: "图书",
            },
            {
              value: "音像",
              label: "音像",
            },
            {
              value: "尾品汇2",
              label: "尾品汇2",
            },
            {
              value: "图书2",
              label: "图书2",
            },
            {
              value: "音像2",
              label: "音像2",
            },
            {
              value: "尾品汇3",
              label: "尾品汇3",
            },
            {
              value: "图书3",
              label: "图书3",
            },
            {
              value: "音像3",
              label: "音像3",
            },
          ],
        },
      ],
      value: "",
    };
  },
  methods: {
    href() {
      location.href = "#/wait";
    },
    loadAll() {
      //服务端接收
      return [
        { value: "三全鲜食（北新泾店）", address: "长宁区新渔路144号" },
        {
          value: "Hot honey 首尔炸鸡（仙霞路）",
          address: "上海市长宁区淞虹路661号",
        },
        {
          value: "新旺角茶餐厅",
          address: "上海市普陀区真北路988号创邑金沙谷6号楼113",
        },
        { value: "泷千家(天山西路店)", address: "天山西路438号" },
        {
          value: "胖仙女纸杯蛋糕（上海凌空店）",
          address: "上海市长宁区金钟路968号1幢18号楼一层商铺18-101",
        },
        { value: "贡茶", address: "上海市长宁区金钟路633号" },
        {
          value: "豪大大香鸡排超级奶爸",
          address: "上海市嘉定区曹安公路曹安路1685号",
        },
        {
          value: "茶芝兰（奶茶，手抓饼）",
          address: "上海市普陀区同普路1435号",
        },
        { value: "十二泷町", address: "上海市北翟路1444弄81号B幢-107" },
        { value: "星移浓缩咖啡", address: "上海市嘉定区新郁路817号" },
        { value: "阿姨奶茶/豪大大", address: "嘉定区曹安路1611号" },
        { value: "新麦甜四季甜品炸鸡", address: "嘉定区曹安公路2383弄55号" },
        {
          value: "Monica摩托主题咖啡店",
          address: "嘉定区江桥镇曹安公路2409号1F，2383弄62号1F",
        },
        {
          value: "浮生若茶（凌空soho店）",
          address: "上海长宁区金钟路968号9号楼地下一层",
        },
        { value: "NONO JUICE  鲜榨果汁", address: "上海市长宁区天山西路119号" },
        { value: "CoCo都可(北新泾店）", address: "上海市长宁区仙霞西路" },
        {
          value: "快乐柠檬（神州智慧店）",
          address: "上海市长宁区天山西路567号1层R117号店铺",
        },
        {
          value: "Merci Paul cafe",
          address: "上海市普陀区光复西路丹巴路28弄6号楼819",
        },
        {
          value: "猫山王（西郊百联店）",
          address: "上海市长宁区仙霞西路88号第一层G05-F01-1-306",
        },
        { value: "枪会山", address: "上海市普陀区棕榈路" },
        { value: "纵食", address: "元丰天山花园(东门) 双流路267号" },
        { value: "钱记", address: "上海市长宁区天山西路" },
        { value: "壹杯加", address: "上海市长宁区通协路" },
        {
          value: "唦哇嘀咖",
          address: "上海市长宁区新泾镇金钟路999号2幢（B幢）第01层第1-02A单元",
        },
        { value: "爱茜茜里(西郊百联)", address: "长宁区仙霞西路88号1305室" },
        {
          value: "爱茜茜里(近铁广场)",
          address:
            "上海市普陀区真北路818号近铁城市广场北区地下二楼N-B2-O2-C商铺",
        },
        {
          value: "鲜果榨汁（金沙江路和美广店）",
          address: "普陀区金沙江路2239号金沙和美广场B1-10-6",
        },
        {
          value: "开心丽果（缤谷店）",
          address: "上海市长宁区威宁路天山路341号",
        },
        { value: "超级鸡车（丰庄路店）", address: "上海市嘉定区丰庄路240号" },
        { value: "妙生活果园（北新泾店）", address: "长宁区新渔路144号" },
        { value: "香宜度麻辣香锅", address: "长宁区淞虹路148号" },
        {
          value: "凡仔汉堡（老真北路店）",
          address: "上海市普陀区老真北路160号",
        },
        { value: "港式小铺", address: "上海市长宁区金钟路968号15楼15-105室" },
        { value: "蜀香源麻辣香锅（剑河路店）", address: "剑河路443-1" },
        { value: "北京饺子馆", address: "长宁区北新泾街道天山西路490-1号" },
        {
          value: "饭典*新简餐（凌空SOHO店）",
          address: "上海市长宁区金钟路968号9号楼地下一层9-83室",
        },
        {
          value: "焦耳·川式快餐（金钟路店）",
          address: "上海市金钟路633号地下一层甲部",
        },
        { value: "动力鸡车", address: "长宁区仙霞西路299弄3号101B" },
        { value: "浏阳蒸菜", address: "天山西路430号" },
        { value: "四海游龙（天山西路店）", address: "上海市长宁区天山西路" },
        {
          value: "樱花食堂（凌空店）",
          address: "上海市长宁区金钟路968号15楼15-105室",
        },
        { value: "壹分米客家传统调制米粉(天山店)", address: "天山西路428号" },
        {
          value: "福荣祥烧腊（平溪路店）",
          address: "上海市长宁区协和路福泉路255弄57-73号",
        },
        {
          value: "速记黄焖鸡米饭",
          address: "上海市长宁区北新泾街道金钟路180号1层01号摊位",
        },
        { value: "红辣椒麻辣烫", address: "上海市长宁区天山西路492号" },
        {
          value: "(小杨生煎)西郊百联餐厅",
          address: "长宁区仙霞西路88号百联2楼",
        },
        { value: "阳阳麻辣烫", address: "天山西路389号" },
        {
          value: "南拳妈妈龙虾盖浇饭",
          address: "普陀区金沙江路1699号鑫乐惠美食广场A13",
        },
      ];
    },
    log() {
      console.log(this.value);
      location.href = "#/wait";
    },
    querySearchAsync(queryString, cb) {
      var restaurants = this.restaurants;
      var results = queryString
        ? restaurants.filter(this.createStateFilter(queryString))
        : restaurants;

      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        cb(results);
      }, 3000 * Math.random());
    },
    createStateFilter(queryString) {
      return (state) => {
        return (
          state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0
        );
      };
    },
    handleSelect(item) {
      console.log(item, 11111111111);
    },
    addBg(e) {
      if (e.target.nodeName == "DIV") {
        e.target.style.backgroundColor = "#fff";
        e.target.style.color = "red";
      }
    },
    removeBg(e) {
      if (e.target.nodeName == "DIV") {
        e.target.style.backgroundColor = "red";
        e.target.style.color = "#fff";
      }
    },
    addC(e) {
      e.target.style.color = "red";
    },
    removeC(e) {
      e.target.style.color = "#000";
    },
  },
  mounted() {
    this.restaurants = this.loadAll();
  },
};
</script>

<style scoped>
#main {
  width: 100vw;
  height: 100px;
  margin: 0;
  position: relative;
}
.logo {
  position: absolute;
  left: 160px;
}
.search {
  position: absolute;
  left: 500px;
  top: 20px;
  height: 100px;
  overflow: hidden;
  vertical-align: top;
}
.el-autocomplete {
  width: 400px;
}
.el-select {
  width: 110px;
}
.el-button {
  background-color: red;
}
.subBox > a {
  margin: 0 10px;
}
.subBox :last-child {
  margin-left: 60px;
}
.buy,
.list {
  display: inline-block;
  width: 110px;
  height: 40px;
  position: absolute;
  line-height: 40px;
  top: 20px;
}
.buy {
  background-color: red;
  left: 1100px;
  color: #fff;
}
.list {
  left: 1200px;
  background-color: #dcdcdc;
  color: #000;
}
</style>
