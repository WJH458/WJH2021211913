<template>
  <div>
    <div id="navMenu">
      <div class="line"></div>
      <el-menu
        :default-active="activeIndex2"
        class="el-menu-demo"
        mode="horizontal"
        @select="handleSelect"
        background-color="#f9f9f9"
        text-color="#646464"
      >
        <el-submenu index="5">
          <template slot="title">送至：{{ position }}</template>
          <el-menu-item
            index="5-1"
            v-for="(item, index) in place"
            :key="index"
            @click="Position(index)"
            style="display: inline-block"
            >{{ item }}</el-menu-item
          >
        </el-submenu>
        <el-menu-item index="1"
          >欢迎光临当当，请
          <a href="#/login" style="color: red">登录</a></el-menu-item
        >
        <el-menu-item index="8" @click="href">成为会员</el-menu-item>
        <el-menu-item index="9" @click="href">
          <i class="buyCart"></i>
          购物车
          <b style="color: red; font-weight: 700">0</b></el-menu-item
        >
        <el-menu-item index="10" @click="href">我的订单</el-menu-item>
        <el-menu-item index="11" @click="href">我的云书房</el-menu-item>
        <el-submenu index="2">
          <template slot="title">我的当当</template>
          <el-menu-item index="2-1" @click="href">选项1</el-menu-item>
          <el-menu-item index="2-2" @click="href">选项2</el-menu-item>
          <el-menu-item index="2-3" @click="href">选项3</el-menu-item>
        </el-submenu>
        <el-submenu index="6">
          <template slot="title">当当拼团</template>
          <el-menu-item index="6-1" @click="href">选项1</el-menu-item>
          <el-menu-item index="6-2" @click="href">选项2</el-menu-item>
          <el-menu-item index="6-3" @click="href">选项3</el-menu-item>
        </el-submenu>
        <el-menu-item index="3" @click="href">小说投稿</el-menu-item>
        <el-submenu index="7">
          <template slot="title">企业采购</template>
          <el-menu-item index="7-1" @click="href">选项1</el-menu-item>
          <el-menu-item index="7-2" @click="href">选项2</el-menu-item>
          <el-menu-item index="7-3" @click="href">选项3</el-menu-item>
        </el-submenu>
        <el-submenu index="4">
          <template slot="title">客服服务</template>
          <el-menu-item index="7-1" @click="href">选项1</el-menu-item>
          <el-menu-item index="7-2" @click="href">选项2</el-menu-item>
          <el-menu-item index="7-3" @click="href">选项3</el-menu-item>
        </el-submenu>
        <el-menu-item index="12" @click="href">切换无障碍</el-menu-item>
      </el-menu>
    </div>
  </div>
</template>

<script>
export default {
  name: "Nav",
  data() {
    return {
      activeIndex: "1",
      activeIndex2: "1",
      place: ["北京", "天津", "河北", "山西", "内蒙古"],
      position: "北京",
    };
  },
  methods: {
    href() {
      location.href = "#/wait";
    },
    handleSelect(key, keyPath) {
      // console.log(key, keyPath);
    },
    Position(index) {
      this.position = this.place[index];
    },
  },
};
</script>

<style scoped>
.el-menu--horizontal > .el-menu-item.is-active {
  border-bottom: none;
}
.buyCart {
  background: url(http://img63.ddimg.cn/upload_img/00459/home/home_sprite2.png)
    no-repeat -40px -86px;
  /* background-size: 100px; */
  display: inline-block;
  width: 20px;
  height: 20px;
}
.el-menu--horizontal > .el-menu-item {
  padding: 0 10px;
  font-size: 12px;
  height: 30px;
  line-height: 30px;
}
.el-menu--horizontal > .el-menu-item:nth-child(2) {
  margin-left: 170px;
  padding: 0;
}
.el-menu {
  padding-left: 160px;
  height: 30px;
  line-height: 30px;
  margin-top: 0;
}
.el-menu-item:nth-child(n) {
  text-align: center;
  font-size: 5px;
}
</style>
