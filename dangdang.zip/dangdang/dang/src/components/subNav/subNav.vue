<template>
  <div>
    <ul>
      <li>
        全部商品分类
        <i class="el-icon-arrow-down"></i>
      </li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">图书</li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">
        电子书
      </li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">
        童装童鞋
      </li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">女装</li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">食品</li>
      <li @mouseover="addColor" @mouseout="removeColor" @click="href">
        母婴玩具
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  methods: {
    href() {
      location.href = "#/wait";
    },
    addColor(e) {
      e.target.style.color = "red";
    },
    removeColor(e) {
      e.target.style.color = "black";
    },
  },
};
</script>

<style scoped>
li {
  /* display: inline-block; */
  float: left;
  width: 90px;
  color: #323232;
  font: 14px/40px "Microsoft Yahei";
  text-decoration: none;
  padding: 0;
  font-weight: bold;
}
li:nth-child(1) {
  width: 200px;
  margin-left: 160px;
  background-color: red;
  color: #fff;
}
.el-icon-arrow-down {
  margin: 0 35px;
  font-size: 20px;
  vertical-align: middle;
}
</style>
