<template>
  <div>
    <div class="title">
      <img class="snapPic" src="../../assets/抢购.png" alt="" />

      <img
        class="snapClo"
        src="../../assets/clock.png"
        alt=""
        style="height: 38px; width: 166.67px"
      />
      <van-count-down :time="time">
        <template #default="timeData">
          <span class="block">{{ timeData.hours }}</span>
          <span class="colon"> </span>
          <span class="block">{{ timeData.minutes }}</span>
          <span class="colon"> </span>
          <span class="block">{{ timeData.seconds }}</span>
        </template>
      </van-count-down>
      <span v-for="(item, index) in changTime" :key="index"
        ><a
          @mouseover="addColor(index)"
          @mouseout="remove"
          :id="active == index ? 'add' : ''"
          :style="nowTime == index ? now : ''"
          href="#/wait"
          ref="chang"
          >{{ item + "场" }}</a
        ></span
      >
    </div>
    <div class="week"></div>
    <div class="snapCon">
      <div v-for="(item, index) in snappedInfo.info" :key="index">
        <div>
          <img :src="snappedInfo.images[0]" :alt="item" />
        </div>
        <div class="name">
          {{ item }}
        </div>
        <div class="price">
          ￥
          <span>{{ snappedInfo.prices[index] }}</span>
          <span class="del">{{ snappedInfo.del[index] }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      time: 100000,
      changTime: ["00:00", "08:00", "12:00", "16:00", "20:00"],
      active: -1,
      nowTime: 0,
      now: "color: red",
      //服务器接收
      snappedInfo: {
        images: [
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
          require("../../../temporary picture/display.jpg"),
        ],
        info: [
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
          "获奖幼儿绘本8册儿童绘本3-6岁经典绘本排行榜故事书7-10岁幼儿睡前故事书儿童绘本故事书幼儿园老师推荐阅读幼儿情绪管理与性格培养行为好习惯勇敢自信逆商教育宝宝图画书0-1-2-4-5-7岁",
        ],
        prices: [26, 27, 28, 29, 30, 15, 14, 13, 22, 21],
        del: [36.2, 37.3, 38.6, 39.4, 40.3, 25.9, 24.2, 23.3, 32.8, 31.4],
      },
    };
  },
  methods: {
    href() {
      location.href = "#/wait";
    },
    addColor(index) {
      this.active = index;
    },
    remove() {
      this.active = -1;
    },
  },
  created() {
    var time = new Date().getHours();
    switch (time) {
      case time >= 0 && time < 8:
        this.nowTime = 0;
        console.log(0);
        break;
      case time > 8 && time < 12:
        this.nowTime = 1;
        console.log(8);
        break;
      case time > 12 && time < 16:
        this.nowTime = 2;
        console.log(12);
        break;
      case time > 16 && time < 20:
        this.nowTime = 3;
        console.log(16);
        break;
      default:
        this.nowTime = 4;
        console.log(20);
        break;
    }
  },
};
</script>

<style scoped>
.title {
  display: inline-block;
  height: 41px;
  width: 990px;
  /* background-color: green; */
  margin: 520px 0 0 0;
  position: relative;
  border-bottom: 3px solid #000;
}
.snapPic,
.snapClo {
  height: 41px;
  float: left;
}
.snapClo {
  padding-left: 30px;
  z-index: -1;
}
.colon {
  display: inline-block;
  margin: 0 8px;
  color: #ee0a24;
}
.block {
  display: inline-block;
  width: 22px;
  color: #000;
  font-size: 14px;
  text-align: center;
  /* background-color: #ee0a24; */
}
.van-count-down {
  position: absolute;
  left: 132px;
  top: 7px;
}
.week {
  width: 200px;
  height: 461px;
  background-color: green;
  display: inline-block;
  position: relative;
  top: 434px;
  right: 5px;
}
.snapCon {
  display: inline-block;
  /* float: left; */
  width: 985px;
  /* height: 280px; */
  /* background-color: red; */
  position: relative;
  right: 102px;
  top: 0px;
  /* border-top: 3.5px solid #000; */
  border-left: 1px solid #e6e6e6;
}
.title a {
  display: inline-block;
  width: 80px;
  height: 41px;
  line-height: 41px;
  font-size: 20px;
  font-weight: bold;
  color: #000;
  margin: 0 20px;
}
#add {
  border-bottom: 3.5px solid red;
  color: red;
}
.snapCon > div {
  float: left;
  flex-flow: row wrap;
  width: 196px;
  height: 210px;
  border-right: 1px solid #e6e6e6;
  border-bottom: 1px solid #e6e6e6;
  background-color: #fff;
  font-size: 12px;
  color: #646464;
}
.name {
  width: 100%;
  height: 22px;
  line-height: 22px;
  overflow: hidden;
  padding: 5px;
}
.price {
  color: #ff2832;
  font-size: 16px;
  padding: 5px;
  text-align: left;
}
.del {
  font-size: 12px;
  padding-left: 5px;
  color: #969696;
  text-decoration: line-through;
}
</style>
