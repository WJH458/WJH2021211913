<template>
  <div class="classify">
    <div>
      <div @mouseleave="remove">
        <ul class="subCategory">
          <li
            v-for="(item, index) in category"
            :key="index"
            @mouseover="add(index)"
            :class="active == index ? 'add' : '_else'"
          >
            <a href="#/wait">{{ item }}</a>
          </li>
        </ul>
        <div class="display" v-if="display">
          <div class="title">
            <div v-for="(item, index) in classification.title" :key="index">
              <span> {{ item }} </span><i class="el-icon-arrow-right"></i>
            </div>
          </div>
          <div
            class="content"
            v-for="(items, index) in classification.content"
            :key="index"
          >
            <span> {{ items.name }} </span>
            <el-breadcrumb separator="|">
              <el-breadcrumb-item
                :to="{ path: '/wait' }"
                v-for="(item, i) in items.list"
                :key="i"
                >{{ item }}</el-breadcrumb-item
              >
            </el-breadcrumb>
          </div>
        </div>
      </div>
      <div class="disLun">
        <van-swipe :autoplay="3000" immediate="true">
          <van-swipe-item v-for="(image, index) in images" :key="index">
            <img @click="href" v-lazy="image" />
          </van-swipe-item>
        </van-swipe>
        <div class="smallLun">
          <van-swipe :autoplay="3000" :show-indicators="false" :height="156">
            <van-swipe-item v-for="(image, index) in images2" :key="index">
              <img @click="href" v-lazy="image" />
            </van-swipe-item>
          </van-swipe>
          <van-swipe :autoplay="3000" :show-indicators="false" :height="156">
            <van-swipe-item v-for="(image, index) in images2" :key="index">
              <img v-lazy="image" />
            </van-swipe-item>
          </van-swipe>
          <van-swipe :autoplay="3000" :show-indicators="false" :height="156">
            <van-swipe-item v-for="(image, index) in images2" :key="index">
              <img @click="href" v-lazy="image" />
            </van-swipe-item>
          </van-swipe>
          <van-swipe :autoplay="3000" :show-indicators="false" :height="156">
            <van-swipe-item v-for="(image, index) in images2" :key="index">
              <img @click="href" v-lazy="image" />
            </van-swipe-item>
          </van-swipe>
          <van-swipe :autoplay="3000" :show-indicators="false" :height="120">
            <van-swipe-item v-for="(image, index) in images2" :key="index">
              <img @click="href" v-lazy="image" />
            </van-swipe-item>
          </van-swipe>
        </div>
      </div>
      <div class="subInfo">
        <img
          @click="href"
          v-for="(img, index) in images4"
          v-lazy="img"
          :key="index"
        />
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
          <el-tab-pane label="信息公告" name="first">
            <li
              @click="href"
              v-for="(item, index) in info_announcement"
              :key="index"
            >
              {{ item }}
            </li>
          </el-tab-pane>
          <el-tab-pane label="服务公告" name="second">
            <li
              @click="href"
              v-for="(item, index) in serve_announcement"
              :key="index"
            >
              {{ item }}
            </li>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      //服务器接收
      category: [
        "图书、童书",
        "电子书",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
        "创意文具",
      ],
      display: false,
      classification: {
        title: ["图书馆", "童书馆"],
        content: [
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
          {
            name: "童书",
            list: ["儿童读物", "儿童读物", "儿童读物", "儿童读物", "儿童读物"],
          },
        ],
      },
      //服务器接收
      storage: [
        {
          title: ["图书馆", "童书馆"],
          content: [
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
            {
              name: "童书",
              list: [
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
                "儿童读物",
              ],
            },
          ],
        },
        {
          title: ["电子书2"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书3"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书4"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书5"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书6"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书7"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书8"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书9"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书10"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书11"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书12"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书13"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书14"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书15"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
        {
          title: ["电子书16"],
          content: [
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
            {
              name: "小说",
              list: [
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
                "武侠小说",
              ],
            },
          ],
        },
      ],
      active: -1,
      // 服务器接收
      images: [
        require("../../../temporary picture/lun.jpeg"),
        require("../../../temporary picture/lun.jpeg"),
        require("../../../temporary picture/lun.jpeg"),
        require("../../../temporary picture/lun.jpeg"),
      ],
      images2: [
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
      ],
      images3: [
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
        require("../../../temporary picture/samllLun.jpeg"),
      ],
      images4: [require("../../../temporary picture/samllLun.jpeg")],
      activeName: "first",
      // 服务器接收
      info_announcement: [
        "图书5折封顶",
        "精选童书5折封顶",
        "图书5折封顶",
        "精选童书5折封顶",
      ],
      serve_announcement: [
        "关于谨防诈骗的重要提示",
        " 话费卡兑换当当礼品卡",
        "关于谨防诈骗的重要提示",
        " 话费卡兑换当当礼品卡",
      ],
    };
  },
  methods: {
    href() {
      location.href = "#/wait";
    },
    add(index) {
      this.display = true;
      this.active = index;
      this.classification = this.storage[index];
    },
    else() {},
    remove() {
      // console.log(11111111);
      this.display = false;
      this.active = -1;
    },
    handleClick(tab, event) {
      console.log(tab, event);
    },
  },
};
</script>

<style scoped>
div {
  text-align: left;
  font-size: 14px;
}
.classify {
  width: 100%;
  /* height: 1500px; */
  /* background-color: green; */
  margin-top: 41px;
  border-top: 3px solid red;
}
.classify > div {
  position: relative;
}
a {
  color: #000;
}
ul {
  float: left;
  background-color: #fafafa;
  margin-left: 160px;
  position: absolute;
  left: 0px;
  z-index: 999;
}
li {
  width: 200px;
  height: 30px;
  text-align: left;
  padding-left: 18px;
}
.display {
  position: absolute;
  left: 355px;
  width: 1000px;
  height: 480px;
  border: 2px solid red;
  border-left: none;
  z-index: 888;
  background-color: #fff;
}
.title {
  width: 1000px;
  height: 35px;
  /* background-color: yellow; */
  line-height: 35px;
}

.title span {
  float: left;
  background-color: #a2a2a2;
  /* display: inline-block; */
  /* width: 60px; */
  padding: 0 10px 0 10px;
  height: 20px;
  line-height: 20px;
  margin: 12.5px 0 12.5px 20px;
  font-size: 16px;
}

.title i {
  background-color: #c8c8c8;
  color: #fff;
  /* display: inline-block; */
  float: left;
  width: 20px;
  height: 20px;
  margin: 12.5px 0 12.5px 0;
  line-height: 20px;
}
.content {
  width: 1000px;
  text-align: left;
  margin: 10px;
}
.content > span {
  font-size: 14px;
  margin: 0 40px 0 10px;
  color: red;
  line-height: 40px;
}
.add {
  border: 2px solid red;
  border-right: none;
}
._else {
  border-right: 2px solid red;
}
.disLun {
  position: absolute;
  left: 355px;
  width: 1000px;
  height: 480px;
  /* background-color: blue; */
}
.smallLun {
  height: 150px;
}
.smallLun .van-swipe:nth-child(1) {
  top: -5px;
}
.smallLun .van-swipe:nth-child(2) {
  top: -161px;
  left: 199px;
}
.smallLun .van-swipe:nth-child(3) {
  top: -317px;
  left: 397px;
}
.smallLun .van-swipe:nth-child(4) {
  top: -473px;
  left: 595px;
}
.smallLun .van-swipe:nth-child(5) {
  top: -593px;
  left: 794px;
}
.smallLun img {
  border: 1px solid #ccc;
}
.subInfo {
  position: absolute;
  right: 170px;
  width: 200px;
  height: 360px;
  background-color: #fff;
}
.el-tabs__item {
  border-radius: 1px;
}
.el-tabs {
  padding-left: 3px;
}
.subInfo li {
  color: #000;
  font-size: 12px;
  list-style: circle inside;
}
</style>
