<template>
  <div id="app">
    <img src="./assets/首页大图.jpeg" alt="" />
    <div>
      <Nav></Nav>
      <InputBox></InputBox>
      <SubNav></SubNav>
      <Classify></Classify>
      <Snapped></Snapped>
    </div>
  </div>
</template>

<script>
import Nav from "./components/Nav/Nav.vue";
import InputBox from "./components/Input/Input.vue";
import subNav from "./components/subNav/subNav.vue";
import Classify from "./components/Classify/Classify.vue";
import Snapped from "./components/Snapped/Snapped.vue";

export default {
  name: "App",
  components: {
    Nav,
    InputBox,
    SubNav: subNav,
    Classify,
    Snapped,
  },
  data() {
    return {
      count: 0,
    };
  },
  methods: {},
};
</script>


<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  outline: 0;
}
html {
  font-size: 1.019025vw; /* 100vw=981.33px，则1rem=10px */
  overflow-x: hidden;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
img,
a {
  text-decoration: none;
  color: #999;
}
ul,
ol {
  list-style: none;
}
em,
i {
  font-style: normal;
}
strong,
b {
  font-weight: 400;
}
li {
  list-style: none;
}
</style>
