<template>
  <div id="app2">
    <router-view></router-view>
  </div>
</template>

<script>
import App from "./App.vue";
export default {
  name: "App2",
  components: {
    App,
  },
  methods: {},
};
</script>


<style>
body {
  width: 100%;
  min-width: 1000px;
}
/* 修改navmenu */
.el-menu--horizontal > .el-submenu .el-submenu__title {
  font-size: 12px;
  height: 30px;
  line-height: 30px;
  padding: 0 10px;
}
.el-menu--horizontal > .el-submenu.is-active .el-submenu__title {
  border-bottom: none;
}
.el-submenu.is-active .el-submenu__title {
  border-bottom-color: none;
}
/* 输入框 */
.el-input__inner {
  border: 2px solid red;
  border-right: 0;
  border-radius: 0;
  display: inline-block;
}

/* 商品分类 */
.el-breadcrumb {
  /* border-bottom: red; */
  display: inline-block;
  height: 40px;
  border-bottom: 1px dotted #ccc;
  line-height: 40px;
  vertical-align: top;
}
.el-breadcrumb__inner a,
.el-breadcrumb__inner.is-link {
  font-weight: 400;
}

/* 轮播图 */
.samllLun .van-swipe {
  width: 200px;
}
</style>
