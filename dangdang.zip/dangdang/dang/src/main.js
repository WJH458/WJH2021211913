import Vue from 'vue'
// import App from './App.vue'
import router from './router'


import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App2 from './App2.vue';

Vue.use(ElementUI);


import Vant, { Lazyload } from 'vant';
import 'vant/lib/index.css';

Vue.use(Vant);
Vue.use(Lazyload);

//导入axios
// import axios from 'axios'

//挂载axios
// Vue.prototype.$http = axios

//配置axios的请求根路径
// axios.defaults.baseURL = ''

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App2)
}).$mount('#app')
