import Vue from 'vue'
import VueRouter from 'vue-router'
import App from '../App.vue'
import Login from '../views/Login/Login.vue'
import Wait from "../views/Wait/Wait.vue"

Vue.use(VueRouter)

//路由规则数组
const routes = [
  {
    path: '/',
    name: 'home',
    component: App
  },
  {
    path: '/wait',
    name: 'wait',
    component: Wait
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  }
]

const router = new VueRouter({
  routes
})

export default router
