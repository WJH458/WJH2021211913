//导入数据库
const db = require('../db/index')

//导入加密模块
const bcrypt = require('bcryptjs')

//获取用户基本信息
module.exports.getUserInfo = (req, res) => {
    //查询数据库信息
    const sql = 'select id, username, nickname, email, user_pic from ev_users where id=?'
    db.query(sql, req.user.id, (err, results) => {
        if (err) return res.cc(err)
        //查询结果不能为空
        if (results.length !== 1) return res.cc('获取用户信息失败！')

        res.send({
            status: 0,
            message: '用户基本信息获取成功！',
            data: results[0],
            // compare: req.user
        })
    })

    // res.send('用户基本信息获取成功！')
}



//更新用户信息
module.exports.updateUserInfo = (req, res) => {
    //获取客户端提交的用户信息
    const userinfo = req.body

    //《可优化》
    //合法性校验
    if (!userinfo.nickname || !userinfo.email) {
        //优化
        return res.cc('昵称或邮箱不合法')
    }

    const sql = 'update ev_users set ? where id=?'
    db.query(sql, [userinfo, req.user.id], (err, results) => {
        if(err) return res.cc(err)
        if(results.affectedRows !== 1) return res.cc('更新用户的基本信息失败!')
        res.cc('更新用户信息成功！', 0)
    })
    // res.send('更新用户信息成功!')
}



//更改用户密码
module.exports.updatepwd = (req, res) => {

    // console.log(req.user);
    //验证新密码不与旧密码相同
    // if(req.body.newpassword == req.user.password) return res.cc('新旧密码不能相同！')

    const newpwd = bcrypt.hashSync(req.body.newpassword, 10)//加密

    //判断旧密码是否相同
    const sql = 'select * from ev_users where id=?'
    db.query(sql, req.user.id, (err, results) => {
        if(err) return res.cc(err)
        const compareResult = bcrypt.compareSync(req.body.oldpassword, results[0].password)
        if(!compareResult) return res.cc('旧密码错误！')

        //更改密码
        const sqlStr = 'update ev_users set password=? where id=?'
        db.query(sqlStr, [newpwd, req.user.id], (err, results) => {
            if(err) return res.cc(err)
            if(results.affectedRows !== 1) return res.cc('更改密码失败！')
            res.cc('更改密码成功！', 0)
        })
    })
    // res.send('更改密码成功！')
}



//更换头像
module.exports.updateAvater = (req, res) => {

     //《可优化》
    //合法性校验
    if (!req.body.avater) {
        return res.cc('头像图片不合法！')
    }

    const sql = "update ev_users set user_pic=? where id=?"
    db.query(sql, [req.body.avater, req.user.id], (err, results) => {
        if(err) return res.cc(err)
        if(results.affectedRows !== 1) return res.cc('更换头像失败！')
        res.cc('更换头像成功！, 0')
    })
    // res.send('更换头像成功！')
}