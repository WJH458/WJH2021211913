//个人中心
const express = require('express')
const router = express.Router()
const router_handler = require('../router_handler/userinfo')

//查看个人信息
router.get('/userinfo', router_handler.getUserInfo)

//更新用户信息
router.post('/userinfo', router_handler.updateUserInfo)

//更改密码
router.post('/updatepwd', router_handler.updatepwd)

//更换头像
router.post('/updateavater', router_handler.updateAvater)

module.exports = router
