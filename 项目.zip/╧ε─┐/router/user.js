const express = require('express')
const router = express.Router()

const router_handler = require('../router_handler/user')

//注册新用户
router.post('/reguser', router_handler.regUser)

//登录
router.post('/login', router_handler.login)

module.exports = router