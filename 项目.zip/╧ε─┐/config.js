//全局配置文件
module.exports = {
    //密钥
    jwtSecretKey: 'wjh NO1.o(*￣▽￣*)ブ',
    //token有效期
    expiresIn: '10h'
    
}